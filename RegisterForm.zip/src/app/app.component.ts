import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  firstName: String = null;
  lastName: String = null;
  email: String = null;
  address: String = null;


  peopleList = [];

  get peopleAmount() {
    return this.peopleList.length;
  }

  savePersonData() {
    this.peopleList.push({ firstName: this.firstName, lastName: this.lastName, email: this.email, address: this.address });
    this.resetForm();
  }

  onSelect(p){
    this.firstName = p.firstName;
    this.lastName = p.lastName;
    this.email = p.email;
    this.address = p.address;
  }

  onDelete(email){
    this.peopleList = this.peopleList.filter(p => p.email != email);

    /*let aux = [];
    this.peopleList.forEach(p => {
      if(p.email != email){
        aux.push(p);
      }
    });    
    this.peopleList = aux;*/
  }

  resetForm() {
    this.firstName = null;
    this.lastName = null;
    this.email = null;
    this.address = null;
  }


  // ----------------------------------------
  title = 'Hello Prog III from Angular';
  name = 'Juanito Alimaña';
  salary = 2500;
  city = 'Manizales';
  genre = 'female';
  carCost = 30000;
  monthAmount = 10;
  canBuy = false;

  ngOnInit() {
    //this.increment();
  }

  increment = () => {
    setInterval(() => {
      this.salary = this.salary + (this.salary * 0.1);
      this.canBuy = (this.salary * this.monthAmount >= this.carCost);
    }, 3000);
  }

}
