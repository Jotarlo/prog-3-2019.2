import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  firstname: String;
  lastname: String;
  email: String;
  phone: String;
  cellphone: String;
  address: String;
  birthdate: String;
  genre: String;

  dataList = [];

  onSaveData() {
    this.dataList.push({
      nombre: this.firstname,
      apellido: this.lastname,
      correo: this.email,
      tel: this.phone,
      celular: this.cellphone,
      dir: this.address,
      fecha: this.birthdate,
      genero: this.genre
    });
    this.clearForm();
  }

  get dataListLength() {
    return this.dataList.length;
  }

  clearForm() {
    this.firstname = null;
    this.lastname = null;
    this.email = null;
    this.phone = null;
    this.cellphone = null;
    this.address = null;
    this.birthdate = null;
    this.genre = null;
  }

  onDeleteClick(email) {
    console.log(email);
    this.dataList = this.dataList.filter(p => p.correo != email);

    /*let aux = [];
    this.dataList.forEach(p => {
      if(p.email != email){
        aux.push(p);
      }
    });
    this.dataList = aux;*/
  }

  onSelectClick(p) {
    this.firstname = p.nombre;
    this.lastname = p.apellido;
    this.email = p.correo;
    this.phone = p.tel;
    this.cellphone = p.celular;
    this.address = p.dir;
    this.birthdate = p.fecha;
    this.genre = p.genero;
  }


  // First example

  title = 'Hello Angular from Component';
  name = 'Pepito';
  age = 19;
  message = null;

  ngOnInit() {
    /*setTimeout(() => {
      this.age = 15;
    }, 4000);*/
  }

}
