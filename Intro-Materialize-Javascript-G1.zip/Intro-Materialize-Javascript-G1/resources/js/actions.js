//alert("Hello world from alert");

//console.log("Hello world form console")

/** Variables definition  */

// constant
const pi = 3.14159265;
console.log(pi);

// variable
var n1;
n1 = 5;

var n2 = 7;

var result = n1 * n2;
console.log("Result = " + result);

// let

let name = "Pepito";
let lastname = "Pérez";

console.log(name + ' ' + lastname + " from concat");
completeName = `${name} ${lastname} from string template`;
console.log(completeName);

let l1 = "5";
let l2 = 4;

console.log(l1 + l2);


/** Functions */

let factIterativo = function (num) {
    let fact = 1;
    for (let i = 2; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

console.log("fact iterativo: " + factIterativo(6));

function factRecursivo(num) {
    if (num == 1) {
        return num;
    }
    return factRecursivo(num - 1) * num;
}
console.log("fact recursivo: " + factRecursivo(6));

let arrowFunction = (n1) => {
    if (n1 % 2 == 0) {
        console.log(factIterativo(n1) + " from iterative function");
    } else {
        console.log(factRecursivo(n1) + " from recursive function");
    }
}

arrowFunction(7);
arrowFunction(10);

console.log("------------------------")

let esPrimo = (n) => {
    for (let i = 2; i < n; i++) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

let verificar = (n1, n2) => {
    if (n1 > n2) {
        console.log("Please, set valid numbers.")
    }
    for (let i = n1; i <= n2; i++) {
        if (esPrimo(i)) {
            console.log(i);
        }
    }
}

let verifyFromHtml = () => {
    let n1 = document.querySelector("#first_number").value;
    let n2 = document.getElementById("second_number").value;

    if ((parseInt(n1) > parseInt(n2)) || n1 == "" || n2 == "") {
        document.querySelector("#taResult").innerHTML = "Please, give me valid numbers!!!";
    }
    let result = "";
    for (let i = n1; i <= n2; i++) {
        if (esPrimo(i)) {
            if (result == "") {
                result = i;
            } else {
                result += ", " + i;
            }
        }
    }
    document.querySelector("#taResult").innerHTML = result;
}





/*setTimeout(() => {
    document.body.style.background = "red";
}, 3000);

let ctl = true;
setInterval(() => {
    if (ctl) {
        document.body.style.background = "red";
    } else {
        document.body.style.background = "gray";
    }
    ctl = !ctl;
}, 2000);

setTimeout(() => {
    document.querySelector("#formDataId").style.display = "block";
}, 1000);*/

let person1 = {
    name: "Pepito",
    lastname: "Pérez",
    age: 18,
    city: "Manizales"
};

let person2 = {
    name: "Juani",
    lastname: "Alimaña",
    age: 25,
    city: "Pereira"
};

let person3 = {
    name: "María",
    lastname: "Hernández",
    age: 15,
    city: "Armenia"
};

let peopleArray = [person1, person2, person3];

let processPeopleArray = () => {
    /*for (let index = 0; index < peopleArray.length; index++) {
        let person = peopleArray[index];
        console.log(person);
    }*/
    let report = "";
    peopleArray.forEach(person => {
        let name = `${person.name} ${person.lastname}`;
        let age = person.age;
        let city = person.city;
        let isMajor = (person.age >= 18) ? "Yes" : "No";
        report += `${name} \t ${age} \t ${city} \t ${isMajor}\n`
    });
    document.querySelector("#taResult").innerHTML = report;
}